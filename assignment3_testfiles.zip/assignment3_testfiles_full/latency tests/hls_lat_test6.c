input Int16 a, b, c, d, e, f, g

variable Int16 h, i, j

output Int16 k, l

h = a * b
i = c * d
j = h + i
k = j / e
l = f / g