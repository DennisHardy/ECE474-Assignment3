input Int16 a, b, c, d, e, f

variable Int16 h, i

output Int16 j, k

h = a * b
i = h + c 
j = i * d 
k = e * f