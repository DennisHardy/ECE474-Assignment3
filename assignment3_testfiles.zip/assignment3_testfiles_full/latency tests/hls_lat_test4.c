input Int16 a, b, c, d, e, f, g

variable Int16 h, i, k

output Int16 j, l

h = a + b
i = h + c 
j = i + d 
k = e * f
l = k * g